// src/components/ui/sonner.jsx
import { Toaster as SonnerToaster } from 'sonner';

export const Toaster = SonnerToaster;