// src/components/ui/use-toast.jsx
import { toast } from 'sonner';

export function useToast() {
  return toast;
}